from flask import Flask

app = Flask(__name__)
app.secret_key = "Sensei, oh Sensei, please give me guidance!"
